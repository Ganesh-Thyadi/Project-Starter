import React from 'react'
import './footer.styles.css'

const Footer = ()=>{
    return(
        <div className="footer-container">
            {/* <div className="footer-heading"> */}
            Proudly Developed by Ashis Kumar Yadav
            {/* </div> */}
        </div>
    )
}


export default Footer;