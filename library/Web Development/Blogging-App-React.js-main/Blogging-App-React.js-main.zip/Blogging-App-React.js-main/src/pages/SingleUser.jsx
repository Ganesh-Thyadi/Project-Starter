import React from 'react'

const SingleUser = () => {
  return (
    <div>SingleUser</div>
  )
}

export default SingleUser